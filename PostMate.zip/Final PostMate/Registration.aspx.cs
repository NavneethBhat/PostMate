﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {

        String str = "insert into registration( name, email, phoneno, password,usertype) values('" + txtname.Text + "','" + txtemail.Text + "','" + txtnum.Text + "','" + txtpass.Text + "','Account Holder')";
        DataLayer dl = new DataLayer();
        dl.DmlCmd(str);
        Response.Write("<script language=javascript> alert(' You have Registered to Postal Account Successfully!!,THANK YOU!!') </script>");
    }
    protected void txtemail_TextChanged(object sender, EventArgs e)
    {

    }
}