﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class saving_report : System.Web.UI.Page
{
    public static string id = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
        }
    }
    public void fillgrid()
    {
        DataLayer dl = new DataLayer();
        DataSet ds = new DataSet();
        String str = "select * from applicant where account_id='" + txtno.Text + "'";
        ds = dl.GetDataSet(str);
        GridView2.DataSource = ds;
        GridView2.DataMember = "table";
        GridView2.DataBind();
    }
    public void fillgrid1()
    {
        DataLayer dl = new DataLayer();
        DataSet ds = new DataSet();
        String str = "select * from new_saving where account_no='" + txtno.Text + "'";
        ds = dl.GetDataSet(str);
        if (ds.Tables[0].Rows.Count > 0)
        {

            GridView1.DataSource = ds;
            GridView1.DataMember = "table";
            GridView1.DataBind();
            int amount = 0;
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                amount = amount + int.Parse(ds.Tables[0].Rows[i]["amount"].ToString());
            }
            int balance = 0;
            String str2 = "select deposit from applicant where account_id='" + txtno.Text + "' and (status='approved' or status='Manual')";
            DataSet ds3 = new DataSet();
            DataLayer d3 = new DataLayer();
            ds3 = d3.GetDataSet(str2);
            if (ds3.Tables[0].Rows.Count > 0)
            {
                balance = int.Parse(ds3.Tables[0].Rows[0]["deposit"].ToString());
            }
            lblamt.Text = balance.ToString();
        }
    }
    protected void btnview_Click(object sender, EventArgs e)
    {
        fillgrid();
        fillgrid1();
    }
}