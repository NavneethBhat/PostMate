﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Net;
using System.Data;
using MySql.Data.MySqlClient;

public partial class _Approved : System.Web.UI.Page
{
    public static string id = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            fillgrid();
        }
    }
    public void fillgrid()
    {
        DataLayer dl = new DataLayer();
        DataSet ds = new DataSet();
        String str = "select * from applicant";
        ds = dl.GetDataSet(str);
        GridView1.DataSource = ds;
        GridView1.DataMember = "table";
        GridView1.DataBind();
    }

    protected void btnapprove_Click(object sender, EventArgs e)
    {
        if (id == null)
        {
            Response.Write("<script language='javascript'>alert('Please choose record')</script>");
        }
        else
        {
            int accountNumber = GenerateAccountNumber();
            string updateQuery = "UPDATE applicant SET status='approved', account_id='" + accountNumber + "' WHERE applicant_id='" + id + "'";
            DataLayer dl = new DataLayer();
            dl.DmlCmd(updateQuery);
            fillgrid();
            using (var client = new SmtpClient())
            {
                client.UseDefaultCredentials = false;
                var NetworkCredentials = new NetworkCredential() { UserName = "akashamishksd@gmail.com", Password = "hobv prkr edtl wajv" };
                client.Port = 587;
                client.EnableSsl = true;
                client.Host = "smtp.gmail.com";
                client.Credentials = NetworkCredentials;

                MailMessage msg = new MailMessage();
                msg.From = new MailAddress("akashamishksd@gmail.com");
                msg.To.Add(GridView1.SelectedRow.Cells[5].Text);
                msg.Subject = "Account Registration";
                msg.Body = "Your ID has been APPROVED !!! Your account number is: " + accountNumber + ". Thank you! PLEASE PROCEED WITH DOCUMENT SUBMISSION";
                    client.Send(msg);
                    Response.Write("<script language=javascript> alert('Approval mail has been sent') </script>");
       

            }
           
        }
   
    }
    protected void btnreject_Click(object sender, EventArgs e)
    {
        if (id == null)
        {

            Response.Write("<script language='javascript'>alert('Please choose record')</script>");
        }
        else
        {
            String str = "update applicant set status='rejected' where applicant_id='" + id + "'";
            DataLayer dl = new DataLayer();
            dl.DmlCmd(str);
            fillgrid();
            using (var client = new SmtpClient())
            {

                client.UseDefaultCredentials = false;
                var NetworkCredentials = new NetworkCredential() { UserName = "akashamishksd@gmail.com", Password = "hobv prkr edtl wajv" };
                client.Port = 587;
                client.EnableSsl = true;
                client.Host = "smtp.gmail.com";
                client.Credentials = NetworkCredentials;

                MailMessage msg = new MailMessage();
                msg.From = new MailAddress("akashamishksd@gmail.com");
                msg.To.Add(GridView1.SelectedRow.Cells[5].Text);
                msg.Subject = "Account Registration";
                msg.Body = "Your ID has been REJECTED";
                client.Send(msg);
                Response.Write("<script language=javascript> alert('Approval mail has been sent') </script>");

            }
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        String txtid = null;
        String txtfname = null;
        String txtstate = null;
        String txtphone = null;
        String txtmail = null;
        String txtstatus = null;
        int rowIndex = Convert.ToInt32(e.CommandArgument);
        GridViewRow row = GridView1.Rows[rowIndex];
        Label lblid = (Label)row.FindControl("lblID");
        id = lblid.Text;
        txtid = GridView1.Rows[rowIndex].Cells[1].Text;
        txtfname = GridView1.Rows[rowIndex].Cells[1].Text;
        txtstate = GridView1.Rows[rowIndex].Cells[1].Text;
        txtphone = GridView1.Rows[rowIndex].Cells[1].Text;
        txtmail = GridView1.Rows[rowIndex].Cells[1].Text;
        txtstatus = GridView1.Rows[rowIndex].Cells[1].Text;
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {
       
            DataLayer dl = new DataLayer();
            DataSet ds = new DataSet();
            String str = null;
            if (rball.Checked == true)
            {
                str = "select * from applicant";
            }
            else if (rbapproved.Checked == true)
            {
                str = "select * from applicant where status='approved'";

            }
            else if (rbrejected.Checked == true)
            {
                str = "select * from applicant where status='rejected'";
            }
            else if (rbmanul.Checked == true)
            {
                str = "select * from applicant where status='Manual'";
            }
            else if (rbonline.Checked == true)
            {
                str = "select * from applicant where status='Online'";
            }
            ds = dl.GetDataSet(str);
            GridView1.DataSource = ds;
            GridView1.DataMember = "table";
            GridView1.DataBind();
        
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    private int GenerateAccountNumber()
    {
        int baseAccountNumber = 10002;

        if (Session["Counter"] != null)
        {
            baseAccountNumber = (int)Session["Counter"] + 1;
        }

        int maxAccountNumber = GetMaxAccountNumberFromDatabase();

        if (baseAccountNumber <= maxAccountNumber)
        {
            baseAccountNumber = maxAccountNumber + 1;
        }

        Session["Counter"] = baseAccountNumber; // Store the updated account number in the session

        // Ensure the account number is within the desired range
        if (baseAccountNumber < 10002)
        {
            baseAccountNumber = 10002;
        }
        else if (baseAccountNumber > 99999)
        {
            // Handle the case where the account number exceeds 99999
            // You can either reset it to 10000 or generate a new random number
            baseAccountNumber = 10002;
        }

        return baseAccountNumber;
    }


    private int GetMaxAccountNumberFromDatabase()
    {
        int maxAccountNumber = 0; // Default value if no records are found

        string connectionString = "Data Source=localhost;initial catalog=postal;Uid=root;Password=root";

        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            string query = "SELECT MAX(CAST(SUBSTRING(account_id, 6) AS UNSIGNED)) FROM applicant";

            connection.Open();
            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                object result = command.ExecuteScalar();
                if (result != DBNull.Value && result != null)
                {
                    maxAccountNumber = Convert.ToInt32(result);
                }
            }
        }

        return maxAccountNumber;
    }




}